package com.researchly.ai

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var question: EditText
    private lateinit var answer: TextView
    private lateinit var tts: TextToSpeech
    private val voiceCode = 20
    private val cameraCode = 21
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(6,22,45)
        tts = TextToSpeech(this) { tts.language = Locale.US }
        val root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(28,28,28,90); setBackgroundColor(android.graphics.Color.rgb(6,22,45)) }
        val title = TextView(this).apply { text="ReSearchly AI"; textSize=28f; setTextColor(android.graphics.Color.WHITE); setPadding(0,0,0,8) }
        val subtitle = TextView(this).apply { text="ASK • RECORD • SCAN • RESEARCH"; textSize=12f; setTextColor(android.graphics.Color.rgb(25,232,255)) }
        question = EditText(this).apply { hint="Ask ReSearchly anything…"; setTextColor(android.graphics.Color.WHITE); setHintTextColor(android.graphics.Color.rgb(143,177,204)); setSingleLine(false) }
        val ask = Button(this).apply { text="ASK"; setOnClickListener { showAnswer() } }
        val voice = Button(this).apply { text="🎙 Voice AI"; setOnClickListener { startVoice() } }
        val scan = Button(this).apply { text="📷 Scan & Ask"; setOnClickListener { startCamera() } }
        answer = TextView(this).apply { textColor(android.graphics.Color.WHITE); textSize=16f; setPadding(0,25,0,0) }
        root.addView(title); root.addView(subtitle); root.addView(question, LinearLayout.LayoutParams(-1,160)); root.addView(ask); root.addView(voice); root.addView(scan); root.addView(answer)
        setContentView(root)
        requestPermissionsIfNeeded()
    }
    private fun TextView.textColor(c:Int){setTextColor(c)}
    private fun requestPermissionsIfNeeded(){ val p= arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CAMERA).filter{ContextCompat.checkSelfPermission(this,it)!=PackageManager.PERMISSION_GRANTED}; if(p.isNotEmpty()) ActivityCompat.requestPermissions(this,p.toTypedArray(),99) }
    private fun startVoice(){ val i=Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH); i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM); i.putExtra(RecognizerIntent.EXTRA_LANGUAGE,Locale.getDefault()); startActivityForResult(i,voiceCode) }
    private fun startCamera(){ val i=Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE); if(i.resolveActivity(packageManager)!=null) startActivityForResult(i,cameraCode) else Toast.makeText(this,"Camera unavailable",Toast.LENGTH_SHORT).show() }
    private fun showAnswer(){ val q=question.text.toString().trim(); if(q.isEmpty()){Toast.makeText(this,"Type or speak a question",Toast.LENGTH_SHORT).show();return}; answer.text="✨ ReSearchly AI\n\nI received: $q\n\nConnect the secure AI research service to generate the full answer, web sources, and document/image analysis." }
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){super.onActivityResult(requestCode,resultCode,data); if(resultCode!=RESULT_OK)return; if(requestCode==voiceCode){val s=data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull(); if(s!=null){question.setText(s);showAnswer()}} else if(requestCode==cameraCode){answer.text="📷 Photo captured. Connect the vision AI service to read and explain this image."}}
    override fun onDestroy(){tts.shutdown();super.onDestroy()}
}
