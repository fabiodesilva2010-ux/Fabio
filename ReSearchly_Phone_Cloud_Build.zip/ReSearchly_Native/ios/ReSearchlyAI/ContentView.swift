import SwiftUI
import AVFoundation

struct ContentView: View {
    @State private var question = ""
    @State private var answer = ""
    @State private var showingCamera = false
    var body: some View {
        ZStack { Color(red:0.024,green:0.086,blue:0.176).ignoresSafeArea()
            ScrollView { VStack(alignment:.leading,spacing:16) {
                Text("ReSearchly AI").font(.largeTitle.bold()).foregroundStyle(.white)
                Text("ASK • RECORD • SCAN • RESEARCH").font(.caption).foregroundStyle(.cyan)
                TextField("Ask ReSearchly anything…", text:$question, axis:.vertical).padding().background(Color.white.opacity(0.08)).clipShape(RoundedRectangle(cornerRadius:14)).foregroundStyle(.white)
                HStack { Button("ASK") { answer="✨ ReSearchly AI\n\nI received: \(question)\n\nConnect the secure AI research service for full answers and sources." }.buttonStyle(.borderedProminent)
                    Button("🎙 Voice AI") { startVoice() }.buttonStyle(.bordered)
                    Button("📷 Scan") { showingCamera=true }.buttonStyle(.bordered) }
                if !answer.isEmpty { Text(answer).foregroundStyle(.white).padding(.top,10) }
            }.padding() }
        }.sheet(isPresented:$showingCamera) { CameraView() }
    }
    func startVoice(){ /* Connect Speech framework / backend here. */ }
}
struct CameraView: View { @Environment(\.dismiss) var dismiss; var body: some View { VStack { Text("Scan & Ask").font(.title).padding(); Text("Camera module ready for vision-AI integration."); Button("Close"){dismiss()} } } }
