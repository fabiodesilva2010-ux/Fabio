import SwiftUI

@main struct ReSearchlyAIApp: App { var body: some Scene { WindowGroup { ContentView() } } }
