# ReSearchly — Build the APK from your phone

This project includes a GitHub Actions workflow that builds the Android APK in the cloud. You do not need Android Studio on your phone.

## Phone steps
1. Create or sign in to a GitHub account.
2. Create a new repository, for example `ReSearchlyAI`.
3. Upload the contents of this project ZIP to the repository. Make sure `.github/workflows/android-apk.yml` is uploaded too.
4. Commit the files to the `main` branch.
5. Open the repository's **Actions** tab.
6. Select **Build ReSearchly APK**.
7. Tap **Run workflow** if it has not started automatically.
8. Wait for the workflow to finish successfully.
9. Open the completed workflow run and scroll to **Artifacts**.
10. Download **ReSearchly-debug-apk** to your Android phone.
11. Extract the downloaded artifact if GitHub gives you a ZIP, then open `app-debug.apk` to install it.

## Important
- This is a debug/test APK, not a signed Google Play release.
- The current app UI/features are a development build. The real production AI backend still needs to be connected before release.
- Never put private API keys or passwords into the repository.
- For Google Play, a signed Android App Bundle (`.aab`) should be produced for the release build.
