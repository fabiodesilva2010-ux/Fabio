# ReSearchly AI release checklist

## Google Play
- Target Android 16 / API 36 for new submissions as of Aug 31, 2026.
- Create a signed Android App Bundle (.aab).
- Complete store listing, privacy/data-safety declarations, content rating and testing.
- Configure production AI/voice/vision backend and secure API keys server-side.

## Apple App Store
- Build with Xcode 26+ and iOS 26 SDK for current App Store submission requirements.
- Create an App Store Connect app record.
- Add icon, screenshots, description, age rating, privacy details and accessibility information.
- Upload signed archive and use TestFlight before review.

## 67 MB target
Treat 67 MB as an optimization target, not a guaranteed store download size. Store delivery can vary by device and packaging.
