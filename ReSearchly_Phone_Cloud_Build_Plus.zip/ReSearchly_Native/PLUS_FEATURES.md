# ReSearchly Plus

ReSearchly now includes a Plus tier in the Android UI.

## Planned Plus benefits
- More AI questions
- Longer voice sessions
- More Scan & Ask uses
- Advanced document analysis
- Priority research tools
- Ad-free experience

## Billing
The current build contains the Plus presentation/UI only. Real paid subscriptions must be connected using Google Play Billing with a parent/guardian or account owner handling the developer/payment setup. A suggested product ID is `researchly_plus_monthly`.
